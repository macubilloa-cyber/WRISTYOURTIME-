import { useState, useMemo } from "react";
import { watches as allWatches, storeConfig } from "./data/watches";
import WatchCard from "./components/WatchCard";
import WatchModal from "./components/WatchModal";
import CompareDrawer from "./components/CompareDrawer";

const BRANDS = ["Todas las marcas", ...new Set(allWatches.map((w) => w.brand))];
const CATEGORIES = ["Todas", ...new Set(allWatches.map((w) => w.category))];
const MAX_PRICE = Math.max(...allWatches.map((w) => w.price));

export default function App() {
  const [search, setSearch] = useState("");
  const [brand, setBrand] = useState("Todas las marcas");
  const [category, setCategory] = useState("Todas");
  const [maxPrice, setMaxPrice] = useState(MAX_PRICE);
  const [selected, setSelected] = useState(null);
  const [favorites, setFavorites] = useState([]);
  const [compare, setCompare] = useState([]);
  const [showCompare, setShowCompare] = useState(false);
  const [showOnlyFavs, setShowOnlyFavs] = useState(false);

  const filtered = useMemo(() => {
    return allWatches.filter((w) => {
      const q = search.toLowerCase();
      const matchSearch = w.name.toLowerCase().includes(q) || w.brand.toLowerCase().includes(q);
      const matchBrand = brand === "Todas las marcas" || w.brand === brand;
      const matchCat = category === "Todas" || w.category === category;
      const matchPrice = w.price <= maxPrice;
      const matchFav = !showOnlyFavs || favorites.includes(w.id);
      return matchSearch && matchBrand && matchCat && matchPrice && matchFav;
    });
  }, [search, brand, category, maxPrice, showOnlyFavs, favorites]);

  const toggleFav = (id) =>
    setFavorites((f) => f.includes(id) ? f.filter((x) => x !== id) : [...f, id]);

  const toggleCompare = (w) => {
    setCompare((c) => {
      if (c.find((x) => x.id === w.id)) return c.filter((x) => x.id !== w.id);
      if (c.length >= 3) return c;
      return [...c, w];
    });
  };

  const resetFilters = () => {
    setSearch("");
    setBrand("Todas las marcas");
    setCategory("Todas");
    setMaxPrice(MAX_PRICE);
    setShowOnlyFavs(false);
  };

  const hasActiveFilters = search || brand !== "Todas las marcas" || category !== "Todas" || maxPrice < MAX_PRICE || showOnlyFavs;

  return (
    <div style={{ minHeight: "100vh", background: "var(--bg)" }}>

      {/* ── HEADER ── */}
      <header style={{
        position: "sticky", top: 0, zIndex: 100,
        background: "rgba(8,8,8,0.96)", backdropFilter: "blur(12px)",
        borderBottom: "1px solid var(--border)",
      }}>
        <div style={{
          maxWidth: 1280, margin: "0 auto",
          padding: "0 32px",
          display: "flex", alignItems: "center", justifyContent: "space-between",
          height: 70,
        }}>
          {/* Logo */}
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <span style={{ color: "var(--gold)", fontSize: 12 }}>◆</span>
              <span style={{
                fontFamily: "var(--font-ui)", fontSize: 18, fontWeight: 600,
                letterSpacing: "0.22em", color: "var(--text)",
              }}>
                {storeConfig.name}
              </span>
            </div>
            <p style={{
              fontFamily: "var(--font-display)", fontStyle: "italic",
              fontSize: 11, color: "#555", letterSpacing: "0.1em", marginTop: 2,
            }}>
              {storeConfig.tagline}
            </p>
          </div>

          {/* Right actions */}
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            {/* Favorites toggle */}
            <button
              onClick={() => setShowOnlyFavs((v) => !v)}
              style={{
                background: showOnlyFavs ? "#ef444422" : "transparent",
                border: `1px solid ${showOnlyFavs ? "#ef4444" : "#2a2a2a"}`,
                color: showOnlyFavs ? "#ef4444" : "#555",
                padding: "7px 14px", borderRadius: 2, cursor: "pointer",
                fontSize: 13, transition: "all 0.2s",
              }}
              title="Mis favoritos"
            >
              ♥ {favorites.length}
            </button>

            {/* Compare button */}
            <button
              onClick={() => setShowCompare(true)}
              disabled={compare.length === 0}
              style={{
                background: compare.length > 0 ? "var(--gold)" : "transparent",
                border: `1px solid ${compare.length > 0 ? "var(--gold)" : "#2a2a2a"}`,
                color: compare.length > 0 ? "#000" : "#555",
                padding: "7px 16px", borderRadius: 2, cursor: compare.length > 0 ? "pointer" : "not-allowed",
                fontSize: 12, fontWeight: 600, letterSpacing: "0.08em",
                transition: "all 0.2s", fontFamily: "var(--font-ui)",
              }}
            >
              ⚖ Comparar {compare.length > 0 ? `(${compare.length})` : ""}
            </button>
          </div>
        </div>
      </header>

      {/* ── HERO ── */}
      <div style={{
        background: "linear-gradient(180deg, #0f0f0f 0%, var(--bg) 100%)",
        borderBottom: "1px solid var(--border)",
        padding: "48px 32px 40px",
        textAlign: "center",
      }}>
        <p style={{
          fontFamily: "var(--font-ui)", fontSize: 10, letterSpacing: "0.3em",
          color: "var(--gold)", marginBottom: 12,
        }}>
          CATÁLOGO EXCLUSIVO
        </p>
        <h1 style={{
          fontFamily: "var(--font-display)", fontSize: "clamp(36px, 6vw, 64px)",
          fontWeight: 300, letterSpacing: "0.06em", margin: "0 0 12px",
          lineHeight: 1.1,
        }}>
          Relojes de Colección
        </h1>
        <p style={{
          fontFamily: "var(--font-display)", fontStyle: "italic",
          fontSize: 16, color: "#777", letterSpacing: "0.05em",
        }}>
          Suizo. Preciso. Eterno.
        </p>
      </div>

      {/* ── FILTERS ── */}
      <div style={{
        position: "sticky", top: 70, zIndex: 99,
        background: "rgba(10,10,10,0.97)", backdropFilter: "blur(10px)",
        borderBottom: "1px solid var(--border)",
        padding: "14px 32px",
      }}>
        <div style={{
          maxWidth: 1280, margin: "0 auto",
          display: "flex", flexWrap: "wrap", gap: 10, alignItems: "center",
        }}>
          {/* Search */}
          <div style={{ position: "relative", flex: "1 1 220px" }}>
            <span style={{
              position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)",
              color: "#444", fontSize: 16, pointerEvents: "none",
            }}>
              ⌕
            </span>
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Buscar reloj o marca..."
              style={{
                width: "100%", background: "#151515",
                border: "1px solid #222", borderRadius: 2,
                padding: "9px 12px 9px 34px", color: "var(--text)",
                fontSize: 13, boxSizing: "border-box",
              }}
            />
          </div>

          {/* Brand */}
          <select
            value={brand} onChange={(e) => setBrand(e.target.value)}
            style={{
              background: "#151515", border: "1px solid #222", borderRadius: 2,
              padding: "9px 14px", color: "var(--text)", fontSize: 13, cursor: "pointer",
            }}
          >
            {BRANDS.map((b) => <option key={b} value={b}>{b}</option>)}
          </select>

          {/* Category */}
          <select
            value={category} onChange={(e) => setCategory(e.target.value)}
            style={{
              background: "#151515", border: "1px solid #222", borderRadius: 2,
              padding: "9px 14px", color: "var(--text)", fontSize: 13, cursor: "pointer",
            }}
          >
            {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>

          {/* Price range */}
          <div style={{ display: "flex", flexDirection: "column", gap: 2, minWidth: 170 }}>
            <span style={{ fontSize: 10, color: "var(--gold)", fontFamily: "var(--font-ui)", letterSpacing: "0.1em" }}>
              HASTA ${maxPrice.toLocaleString()}
            </span>
            <input
              type="range" min={500} max={MAX_PRICE} step={100}
              value={maxPrice} onChange={(e) => setMaxPrice(Number(e.target.value))}
              style={{ accentColor: "var(--gold)", cursor: "pointer" }}
            />
          </div>

          {/* Reset + count */}
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginLeft: "auto" }}>
            {hasActiveFilters && (
              <button
                onClick={resetFilters}
                style={{
                  background: "transparent", border: "1px solid #2a2a2a",
                  color: "#666", padding: "6px 12px", borderRadius: 2,
                  cursor: "pointer", fontSize: 11, fontFamily: "var(--font-ui)",
                }}
              >
                ✕ Limpiar
              </button>
            )}
            <span style={{ fontSize: 11, color: "#444", fontFamily: "var(--font-ui)", letterSpacing: "0.08em" }}>
              {filtered.length} {filtered.length === 1 ? "reloj" : "relojes"}
            </span>
          </div>
        </div>
      </div>

      {/* ── GRID ── */}
      <main style={{
        maxWidth: 1280, margin: "0 auto",
        padding: "40px 32px 80px",
      }}>
        {filtered.length === 0 ? (
          <div style={{ textAlign: "center", padding: "100px 0", color: "#333" }}>
            <div style={{ fontSize: 56, marginBottom: 16 }}>⌚</div>
            <p style={{ fontFamily: "var(--font-display)", fontSize: 20, fontStyle: "italic" }}>
              No hay relojes con esos filtros
            </p>
            <button onClick={resetFilters} style={{
              marginTop: 20, background: "transparent", border: "1px solid #2a2a2a",
              color: "var(--gold)", padding: "10px 24px", borderRadius: 2,
              cursor: "pointer", fontSize: 12, fontFamily: "var(--font-ui)", letterSpacing: "0.1em",
            }}>
              Ver todos
            </button>
          </div>
        ) : (
          <div style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
            gap: 24,
          }}>
            {filtered.map((w, i) => (
              <div key={w.id} style={{ animationDelay: `${i * 0.05}s` }}>
                <WatchCard
                  watch={w}
                  onSelect={setSelected}
                  onToggleFav={toggleFav}
                  isFav={favorites.includes(w.id)}
                  onToggleCompare={toggleCompare}
                  inCompare={!!compare.find((x) => x.id === w.id)}
                />
              </div>
            ))}
          </div>
        )}
      </main>

      {/* ── FOOTER ── */}
      <footer style={{
        borderTop: "1px solid var(--border)",
        padding: "28px 32px",
        textAlign: "center",
        background: "#0a0a0a",
      }}>
        <p style={{
          fontFamily: "var(--font-ui)", fontSize: 9,
          letterSpacing: "0.25em", color: "#2a2a2a",
        }}>
          ◆ {storeConfig.name} · {storeConfig.tagline} · {new Date().getFullYear()} ◆
        </p>
      </footer>

      {/* ── MODAL ── */}
      {selected && (
        <WatchModal
          watch={selected}
          onClose={() => setSelected(null)}
          isFav={favorites.includes(selected.id)}
          onToggleFav={toggleFav}
        />
      )}

      {/* ── COMPARE DRAWER ── */}
      {showCompare && (
        <CompareDrawer
          watches={compare}
          onRemove={(id) => setCompare((c) => c.filter((x) => x.id !== id))}
          onClear={() => { setCompare([]); setShowCompare(false); }}
        />
      )}

      {/* ── COMPARE FAB (floating) ── */}
      {compare.length > 0 && !showCompare && (
        <button
          onClick={() => setShowCompare(true)}
          style={{
            position: "fixed", bottom: 28, right: 28, zIndex: 300,
            background: "var(--gold)", color: "#000",
            border: "none", borderRadius: 2,
            padding: "14px 20px", cursor: "pointer",
            fontSize: 13, fontWeight: 700, letterSpacing: "0.08em",
            fontFamily: "var(--font-ui)",
            boxShadow: "0 8px 32px rgba(201,168,76,0.4)",
            animation: "fadeUp 0.3s ease",
          }}
        >
          ⚖ Comparar ({compare.length})
        </button>
      )}
    </div>
  );
}
